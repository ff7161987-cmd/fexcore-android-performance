# Instalação no Winlator/Ludashi

Este pacote contém binários ARM64 Linux do FEXCore/FEX compilados em Release. Ele não executa x86_64 nativamente: continua traduzindo x86_64 para ARM64. Os caminhos internos variam entre Winlator, Ludashi e forks.

1. Faça backup dos arquivos FEX/FEXCore atuais da sua instalação ou container.
2. Extraia o pacote em um local temporário.
3. Confirme no Android/ambiente ARM64 que `FEX` é `aarch64` antes de substituir qualquer arquivo.
4. Substitua somente o componente FEX correspondente da sua variante, preservando permissões executáveis. Se o fork não usa um FEX externo ou espera uma biblioteca com ABI diferente, não force a substituição; restaure o backup.
5. Reinicie o container e teste primeiro um aplicativo simples. Depois compare ETS2 no mesmo save, resolução, preset, DXVK/VKD3D, Wine/Proton e modo de energia.
6. Se houver crash, stutter novo ou tela preta, restaure imediatamente os arquivos originais e guarde os logs do Winlator/Ludashi.

O pacote inclui `bin/FEX`, ferramentas auxiliares e `lib/libFEXCore.so`. A integração de `libFEXCore.so` depende do fork e da forma como ele carrega o FEXCore; não copie a biblioteca para um caminho arbitrário sem confirmar a ABI esperada pela sua versão.

Para conferir o artefato no Linux/Termux:

```sh
file bin/FEX
sha256sum -c SHA256SUMS
```

Não há resultados de FPS, consumo ou shader compilados neste pacote. Esses números só podem ser obtidos no seu dispositivo usando o mesmo jogo e a mesma configuração antes/depois.
